"""Deterministyczne wykrywanie danych przez wyrażenia regularne.

Dla identyfikatorów z sumą kontrolną (PESEL, NIP, REGON, dowód) dopasowanie
jest dodatkowo weryfikowane algorytmem kontrolnym — to radykalnie obcina
fałszywe trafienia (przypadkowe ciągi cyfr).
"""

import re

# --------------------------------------------------------------------------
# Walidatory sum kontrolnych
# --------------------------------------------------------------------------

def valid_pesel(s: str) -> bool:
    if len(s) != 11 or not s.isdigit():
        return False
    w = [1, 3, 7, 9, 1, 3, 7, 9, 1, 3]
    c = sum(int(s[i]) * w[i] for i in range(10)) % 10
    control = (10 - c) % 10
    if control != int(s[10]):
        return False
    # Sprawdzenie sensowności miesiąca (kodowanie stulecia: +0/20/40/60/80)
    mm = int(s[2:4]) % 20
    dd = int(s[4:6])
    return 1 <= mm <= 12 and 1 <= dd <= 31


def valid_nip(s: str) -> bool:
    d = re.sub(r"\D", "", s)
    if len(d) != 10:
        return False
    w = [6, 5, 7, 2, 3, 4, 5, 6, 7]
    c = sum(int(d[i]) * w[i] for i in range(9)) % 11
    return c != 10 and c == int(d[9])


def valid_regon(s: str) -> bool:
    d = re.sub(r"\D", "", s)
    if len(d) == 9:
        w = [8, 9, 2, 3, 4, 5, 6, 7]
        c = sum(int(d[i]) * w[i] for i in range(8)) % 11 % 10
        return c == int(d[8])
    if len(d) == 14:
        w = [2, 4, 8, 5, 0, 9, 7, 3, 6, 1, 2, 4, 8]
        c = sum(int(d[i]) * w[i] for i in range(13)) % 11 % 10
        return c == int(d[13])
    return False


def valid_dowod(s: str) -> bool:
    s = s.replace(" ", "").upper()
    if not re.fullmatch(r"[A-Z]{3}\d{6}", s):
        return False
    vals = [ord(c) - 55 if c.isalpha() else int(c) for c in s]
    order = [0, 1, 2, 4, 5, 6, 7, 8]          # bez cyfry kontrolnej (indeks 3)
    weights = [7, 3, 1, 7, 3, 1, 7, 3]
    check = sum(vals[order[i]] * weights[i] for i in range(8)) % 10
    return check == vals[3]


# --------------------------------------------------------------------------
# Wzorce
# --------------------------------------------------------------------------

MONTHS = ("stycznia|lutego|marca|kwietnia|maja|czerwca|lipca|"
          "sierpnia|września|wrzesnia|października|pazdziernika|listopada|grudnia")

# Wielkie litery polskie (do wzorca adresu).
_UC = "A-ZŻŹĆĄŚĘŁÓŃ"

# Każda reguła: (kategoria, skompilowany wzorzec, walidator-lub-None, grupa)
# grupa -> który grupujący nawias zawiera właściwą wartość (0 = całość)
_RULES = [
    ("EMAIL",
     re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"),
     None, 0),

    # IBAN/NRB: opcjonalne PL + 26 cyfr (zlepione lub w grupach po 4)
    ("IBAN",
     re.compile(r"(?<![A-Za-z0-9])(?:PL\s?)?\d{2}(?:\s?\d{4}){6}(?![\d])"),
     None, 0),

    ("PESEL",
     re.compile(r"(?<!\d)\d{11}(?!\d)"),
     valid_pesel, 0),

    # NIP: 10 cyfr, dozwolone separatory; opcjonalny przedrostek PL
    ("NIP",
     re.compile(r"(?<![\w\-])(?:PL)?\d{3}[-\s]?\d{3}[-\s]?\d{2}[-\s]?\d{2}(?![\d\-])"),
     valid_nip, 0),

    ("REGON",
     re.compile(r"(?<!\d)(?:\d{14}|\d{9})(?!\d)"),
     valid_regon, 0),

    # KRS rozpoznajemy tylko przy słowie-kluczu, by nie mylić z NIP/REGON
    ("KRS",
     re.compile(r"\bKRS[\s:.\-]*?(\d{10})\b", re.IGNORECASE),
     None, 1),

    ("DOWOD",
     re.compile(r"\b[A-Z]{3}\s?\d{6}\b"),
     valid_dowod, 0),

    ("PASZPORT",
     re.compile(r"\b[A-Z]{2}\s?\d{7}\b"),
     None, 0),

    ("KOD_POCZTOWY",
     re.compile(r"(?<!\d)\d{2}-\d{3}(?!\d)"),
     None, 0),

    # Telefon: opcjonalnie +48 / 0048, układ 3-3-3 lub 2-3-2-2
    ("TELEFON",
     re.compile(r"(?<![\w])(?:(?:\+|00)\s?48[\s\-]?)?"
                r"(?:\d{3}[\s\-]\d{3}[\s\-]\d{3}|\d{2}[\s\-]\d{3}[\s\-]\d{2}[\s\-]\d{2}|"
                r"(?:\+|00)\s?48\s?\d{9})(?![\w])"),
     None, 0),

    ("DATA",
     re.compile(r"\b\d{4}-\d{2}-\d{2}\b"
                r"|\b\d{1,2}[.\-/]\d{1,2}[.\-/]\d{2,4}\b"
                r"|\b\d{1,2}\s+(?:" + MONTHS + r")\s+\d{4}\s*r?\.?", re.IGNORECASE),
     None, 0),

    # Adres: ul./al./pl./os. + nazwa + numer (uzupełnia model Bielik)
    ("ADRES",
     re.compile(r"(?:[Uu]l(?:\.|ica)?|[Aa]l(?:\.|eja)?|[Pp]l(?:\.|ac)?|[Oo]s(?:\.|iedle)?)\s+"
                r"[%s][^\s,;]*(?:\s+[%s\d][^\s,;]*){0,3}\s+\d+[A-Za-z]?(?:\s*/\s*\d+[A-Za-z]?)?"
                % (_UC, _UC)),
     None, 0),

    # Tablice rejestracyjne — wymagamy cyfry w części numerowej (mniej fałszywek);
    # i tak domyślnie wyłączone w interfejsie.
    ("TABLICA",
     re.compile(r"\b[A-Z]{2,3}[ -]?(?=[A-Z0-9]{4,5}\b)(?=[A-Z0-9]*\d)[A-Z0-9]{4,5}\b"),
     None, 0),
]


def find_structured(text: str, enabled=None):
    """Zwraca listę dopasowań: {start, end, surface, category, source}.

    enabled — opcjonalny zbiór nazw kategorii; jeśli podany, pozostałe są pomijane.
    """
    out = []
    for category, pattern, validator, group in _RULES:
        if enabled is not None and category not in enabled:
            continue
        for m in pattern.finditer(text):
            start, end = m.span(group)
            surface = m.group(group)
            if not surface:
                continue
            if validator is not None and not validator(surface):
                continue
            out.append({
                "start": start,
                "end": end,
                "surface": surface,
                "category": category,
                "source": "regex",
            })
    return out
