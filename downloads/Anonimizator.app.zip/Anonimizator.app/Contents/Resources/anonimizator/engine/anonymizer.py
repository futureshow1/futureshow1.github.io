"""Rdzeń anonimizacji: łączenie źródeł wykrywania, rozwiązywanie nakładek,
nadawanie spójnych tokenów i odwracalna deanonimizacja.

Token ma postać [PREFIKS_N], np. [OSOBA_1], [PESEL_2]. Ten sam byt (np. ta sama
osoba w różnych formach) dostaje zawsze ten sam token — dzięki temu model AI
zachowuje powiązania, a po pracy można jednym ruchem przywrócić dane.
"""

from .categories import CATEGORY_META, PRIORITY
from . import regex_rules, dictionaries, ner_bielik


# --------------------------------------------------------------------------
# Wykrywanie (łączy regex + Bielik / słowniki)
# --------------------------------------------------------------------------

def detect(text, enabled=None, use_bielik=True, model=None, progress=None):
    """Zwraca (spans, info). info zawiera m.in. użyte źródło nazw."""
    spans = regex_rules.find_structured(text, enabled)
    info = {"bielik": False, "fallback": False}

    if use_bielik and ner_bielik.available():
        spans += ner_bielik.detect_entities(text, model=model, enabled=enabled, progress=progress)
        info["bielik"] = True
    else:
        spans += dictionaries.find_names_dict(text, enabled)
        info["fallback"] = True

    spans = resolve_overlaps(spans)
    for i, s in enumerate(spans):
        s["id"] = i
    return spans, info


# --------------------------------------------------------------------------
# Nakładki
# --------------------------------------------------------------------------

def _overlap(a, b):
    return not (a["end"] <= b["start"] or a["start"] >= b["end"])


def resolve_overlaps(spans):
    """Gdy dopasowania się nakładają, wygrywa kategoria o wyższym priorytecie,
    a przy remisie — dłuższy span."""
    ordered = sorted(
        spans,
        key=lambda s: (-PRIORITY.get(s["category"], 0),
                       -(s["end"] - s["start"]), s["start"]),
    )
    taken, keep = [], []
    for s in ordered:
        if any(_overlap(s, t) for t in taken):
            continue
        taken.append(s)
        keep.append(s)
    keep.sort(key=lambda s: s["start"])
    return keep


# --------------------------------------------------------------------------
# Tokeny i mapowanie
# --------------------------------------------------------------------------

def assign_tokens(spans):
    """Nadaje spójne tokeny; modyfikuje spans (dodaje 'token') i zwraca mapowanie."""
    spans.sort(key=lambda s: s["start"])
    by_key, counters, acc = {}, {}, {}

    for s in spans:
        cat = s["category"]
        prefix = CATEGORY_META[cat]["prefix"]
        key = s.get("group") or (cat + "::" + s["surface"].lower())
        if key not in by_key:
            counters[prefix] = counters.get(prefix, 0) + 1
            token = "[%s_%d]" % (prefix, counters[prefix])
            by_key[key] = token
            acc[token] = {"category": cat, "warianty": set()}
        token = by_key[key]
        s["token"] = token
        acc[token]["warianty"].add(s["surface"])

    mapping = {}
    for token, info in acc.items():
        variants = sorted(info["warianty"], key=len, reverse=True)
        mapping[token] = {
            "category": info["category"],
            "canonical": variants[0],          # najpełniejsza forma
            "warianty": sorted(info["warianty"]),
        }
    return mapping


def _apply(text, spans):
    spans = sorted(spans, key=lambda s: s["start"])
    out, last = [], 0
    for s in spans:
        if s["start"] < last:                  # bezpiecznik na nakładki
            continue
        out.append(text[last:s["start"]])
        out.append(s["token"])
        last = s["end"]
    out.append(text[last:])
    return "".join(out)


def anonymize(text, spans):
    """Zwraca (anon_text, mapping, spans_with_tokens)."""
    spans = resolve_overlaps(spans)
    mapping = assign_tokens(spans)
    return _apply(text, spans), mapping, spans


def deanonymize(text, mapping):
    """Przywraca dane: każdy token zamienia na formę kanoniczną."""
    for token, val in sorted(mapping.items(), key=lambda kv: len(kv[0]), reverse=True):
        canonical = val.get("canonical") if isinstance(val, dict) else val
        text = text.replace(token, canonical)
    return text


# --------------------------------------------------------------------------
# Raport
# --------------------------------------------------------------------------

def make_report(mapping):
    """Czytelna tabela mapowania (token -> oryginał), pogrupowana kategoriami."""
    lines = ["RAPORT ANONIMIZACJI", "=" * 50, ""]
    by_cat = {}
    for token, val in mapping.items():
        by_cat.setdefault(val["category"], []).append((token, val))
    for cat in sorted(by_cat):
        lines.append("[%s] %s" % (cat, CATEGORY_META[cat]["label"]))
        for token, val in sorted(by_cat[cat], key=lambda kv: kv[0]):
            extra = ""
            others = [w for w in val["warianty"] if w != val["canonical"]]
            if others:
                extra = "   (formy: " + ", ".join(others) + ")"
            lines.append("   %-14s -> %s%s" % (token, val["canonical"], extra))
        lines.append("")
    lines.append("Liczba zanonimizowanych bytów: %d" % len(mapping))
    return "\n".join(lines)
