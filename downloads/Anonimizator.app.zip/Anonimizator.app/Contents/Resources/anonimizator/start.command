#!/bin/bash
# Anonimizator — uruchamianie jednym kliknięciem (macOS).
# Przy pierwszym starcie tworzy środowisko i instaluje zależności.

cd "$(dirname "$0")" || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo "Nie znaleziono python3."
  echo "Zainstaluj Pythona 3 (https://www.python.org/downloads/) i uruchom ponownie."
  read -r -p "Naciśnij Enter, aby zamknąć…"
  exit 1
fi

if [ ! -d ".venv" ]; then
  echo "Pierwsze uruchomienie — przygotowuję środowisko…"
  python3 -m venv .venv || { echo "Nie udało się utworzyć środowiska."; read -r; exit 1; }
  if [ -d wheels ] && ./.venv/bin/python -m pip install -q --no-index --find-links wheels -r requirements.txt 2>/dev/null; then
    echo "Zależności gotowe (offline)."
  else
    ./.venv/bin/python -m pip install -q -r requirements.txt || { echo "Błąd instalacji zależności."; read -r; exit 1; }
  fi
fi

echo ""
echo "  Anonimizator działa →  http://127.0.0.1:8143"
echo "  (zamknij to okno lub naciśnij Ctrl+C, aby zatrzymać)"
echo ""
echo "  Rozpoznawanie nazwisk: lokalny model Bielik (jeśli jest);"
echo "  w przeciwnym razie tryb słownikowy. Pierwsza instalacja: Instalator.command"
echo ""

# Jeśli Ollama jest zainstalowana, a usługa nie działa — uruchom ją (dla Bielika).
if ! curl -s --max-time 2 http://localhost:11434/api/tags >/dev/null 2>&1; then
  if [ -d /Applications/Ollama.app ]; then
    open -a Ollama >/dev/null 2>&1 || true
  elif command -v ollama >/dev/null 2>&1; then
    nohup ollama serve >/dev/null 2>&1 &
  fi
fi

exec env ANON_OPEN=1 ./.venv/bin/python app.py
