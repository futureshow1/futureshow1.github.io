import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine.regex_rules import find_structured, valid_pesel, valid_nip, valid_regon
from engine.dictionaries import find_names_dict

t = """Pan Jan Kowalski (PESEL 44051401359) zam. ul. Kwiatowa 5, 00-950 Warszawa,
tel. +48 601 234 567, e-mail jan.kowalski@example.com.
Firma ABC Sp. z o.o., NIP 123-456-32-18, REGON 123456785, KRS 0000123456.
Konto: PL61 1090 1014 0000 0712 1981 2874. Spotkanie 12.03.2026 r.
Druga strona: Anna Nowak, dowod ABA300000."""

print("PESEL:", valid_pesel("44051401359"), "NIP:", valid_nip("1234563218"), "REGON:", valid_regon("123456785"))
print("--- structured ---")
for d in find_structured(t):
    print("  %-14s %r" % (d["category"], d["surface"]))
print("--- names (dict fallback) ---")
for d in find_names_dict(t):
    print("  %-14s %r" % (d["category"], d["surface"]))
