import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine import anonymizer

TEXT = """PROTOKÓŁ Z MEDIACJI

Strona 1: Jan Kowalski, PESEL 44051401359, zam. ul. Kwiatowa 5, 00-950 Warszawa,
tel. +48 601 234 567, e-mail jan.kowalski@example.com.
Strona 2: Anna Nowak, prowadzona przez kancelarię Lex Sp. z o.o., NIP 123-456-32-18.

W toku spotkania Kowalskiemu przedstawiono propozycję. Nowak nie zgodziła się z
Kowalskim. Strony ustaliły kolejny termin w Krakowie."""

t0 = time.time()
spans, info = anonymizer.detect(TEXT, use_bielik=True)
anon, mapping, _ = anonymizer.anonymize(TEXT, spans)
print("źródło nazw:", "Bielik" if info["bielik"] else "słownik (fallback)",
      "| czas: %.1fs" % (time.time() - t0))
print("\n===== TEKST ZANONIMIZOWANY =====\n" + anon)
print("\n===== RAPORT =====\n" + anonymizer.make_report(mapping))

# Symulacja: AI zwraca tekst z tokenami -> deanonimizujemy
ai_response = "Podsumowanie: [OSOBA_1] oraz [OSOBA_2] ustalili termin w [MIEJSCE_1]. Kontakt: [EMAIL_1]."
print("===== DEANONIMIZACJA ODPOWIEDZI AI =====")
print("wejście :", ai_response)
print("wyjście :", anonymizer.deanonymize(ai_response, mapping))
